﻿using System.Runtime.CompilerServices;

namespace ExtensionMethods
{
    internal class Program
    {
        static void Main(string[] args)
        {

            //ParentClass parentClass = new ParentClass();

            //parentClass.Test1();
            //parentClass.Test2();

            //parentClass.Test3();
            //parentClass.Test4(10);
            //parentClass.Test5();
            //string word = "hi hello Welcome to dotnet tutorial";
            //int count = word.wordCount();
            //Console.WriteLine($"Word Count {count}");

            List<int> list = new List<int>()
            { 10,20,30,40,50,60,70};

            var result = list.Where(x => x > 20).ToList();

            foreach (var item in result)
            {
                Console.WriteLine(item);
            }
            Console.ReadLine();
        }
    }


    //public static class stringExtension
    //{
    //    public static int wordCount(this string s)
    //    {
    //        if (!string.IsNullOrEmpty(s))
    //        {
    //            string[] array = s.Split(' ');
    //            return array.Length;
    //        }
    //        else
    //        {
    //            return 0;
    //        }
    //    }
    //}

    //public class ParentClass
    //{
    //    public int x = 100;
    //    public void Test1()
    //    {
    //        Console.WriteLine($"Method 1 : {x}");
    //    } public void Test2()
    //    {
    //        Console.WriteLine($"Method 2 : {x}");
    //    }
    //}
    //public static class ChildClass
    //{
    //    public static void Test3(this ParentClass p)
    //    {
    //        Console.WriteLine($"Method 3 ");
    //    }
    //    public static void Test4(this ParentClass p,int x)
    //    {
    //        Console.WriteLine($"Method 4 : {x}");
    //    } public static void Test5(this ParentClass p)
    //    {
    //        Console.WriteLine($"Method 5 : {p.x}");
    //    }
    //}
}
